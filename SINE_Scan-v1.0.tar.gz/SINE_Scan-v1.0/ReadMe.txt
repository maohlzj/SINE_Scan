#########a brief introduction to SINE_Scan-v1.0#########
1. The most important thing is that reading user guide clearly before you use SINE_Scan;
2. an example:
(1). INSTALL: perl SINE_Scan_Installer.pl -d /Mac_home/SINE/SINE_Scan -f makeblastdb -b blastn -M /Mac_home/software/Muscle/muscle -e /Mac_home/software/EMBOSS/stretcher -c /Mac_home/software/cd-hit/cd-hit-est -S /Mac_home/database/SINE/sines.fasta -R /Mac_home/database/RNA/rna.intergated.fasta
(2). RUN: perl SINE_Scan_process.pl -s 123 -g Rice.fasta -o Oryza_sativa_v7.0 -d Workdir
(3). Final outputs: three files, one .gff file, two .fasta files;
