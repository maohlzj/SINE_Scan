use strict;
if(@ARGV<1){
	print "$0 <solar>\n";
	exit(0);
}

my %entry;
open fin,"<$ARGV[0]" or die $!;
while(<fin>){
	chomp;
	if(/^\s*$/){
		next;
	}
	my @x=split(/\t+/,$_);
	if($x[0]=~/(\w{3})\|(.+\_\d+\_\d+)#(\S+)/){
		my $code=$1;
		my $id=$2;
		my $fam=(split(/\_/,$id))[0];
		my $class=$3;
		$entry{$id}{"$x[5]\tTE\t$class/$fam\t$x[7]\t$x[8]\t.\t$x[4]\t."}=1;
	}
	my $id=$x[0];
	my @a=split(/;/,$x[12]);
	$entry{$id}{"$x[5]\tTE\tclass/family\t$x[7]\t$x[8]\t.\t$x[4]\t."}=1;
}
close fin;

foreach my $id(sort keys %entry){
	my $n=0;
	foreach my $info(sort keys %{$entry{$id}}){
		++$n;
		print "$info\tgene_id \"$id.$n\";\n";
	}
}
