#!usr/bin/perl
use strict;

if(@ARGV < 2){
	warn "please enter : TE_list genome_file\n";
	exit 0;
} 

open IN,$ARGV[0] or die "$!\n";
my $line;
my %name=();
while(defined($line=<IN>)){
	chomp $line;
	my @s=split(/\t/,$line);
	my $flag='+';
	if($s[8]-$s[9] < 0){
		$flag='-';
	}
	my $u="$s[0]:$flag";	
	my @a=split(/:/,$s[0]);
	$name{$u}=$a[0];
}
close IN;

open IN,$ARGV[1] or die "$!\n";
my %chr=();
my $r="";
while(defined($line=<IN>)){
	chomp $line;
	if($line=~/>/){
		$line=~s/>//;
		my @s=split(/\s+/,$line);
		if(exists $chr{$r}){
			foreach my $i (keys%name){
				my @a=split(/:/,$i);
				my @b=split(/-/,$a[1]);
				if($name{$i} eq $r){
					my $seq=substr($chr{$r},$b[0],$b[1]-$b[0]+1);
					if($a[2] eq '-'){
						$seq=rev($seq);
					}	
					print ">$i\n$seq\n";
				}
			}
		}
		$chr{$r}="";
		$chr{$s[0]}="";
		$r=$s[0];
	}else{
		$chr{$r}.=$line;
	}
}
close IN;

foreach my $i (keys%name){
	my @a=split(/:/,$i);
	my @b=split(/-/,$a[1]);
	if($name{$i} eq $r){
		my $seq=substr($chr{$r},$b[0],$b[1]-$b[0]+1);
		print ">$i\n$seq\n";
	}
}
undef%name;
undef%chr;

sub rev{
        my $x=reverse($_[0]);
        $x=~tr/ATCG/TAGC/;
        $x=~tr/atcg/tagc/;
        return($x);
}
