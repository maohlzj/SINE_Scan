#!usr/bin/perl
use strict;

$genome=$ARGV[0];

	if(-e $genome.".nal"){
		open in,$genome.".nal" or die "$!\n";
		while(<in>){
			if($_=/DBLIST/){
				chomp $_;
				my @s=split(/\s+/,$_);
				shift @s;
				foreach my $i (@s){
					my @a=split(/\./,$i);
					my $w=$genome.".$a[-1]";
					push @files,$w;
				}
			}
		}
		close in;	
	}else{
		push @files,$genome;
	}
	my $flag=0;
	foreach my $j (@files){
		if(-e $j.".nhr" and -e $j.".nin" and -e $j."nsq"){
			$flag=1;
		}else{
			$flag=0;
		}
	}
	
	if($flag == 1){
		print "Genomic database exists.\n";
	}
