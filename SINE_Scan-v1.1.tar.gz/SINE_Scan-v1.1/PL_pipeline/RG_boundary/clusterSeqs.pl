#!usr/bin/perl
use strict;
use File::Basename;

open in,$ARGV[0] or die "$!\n";
my $path=dirname($ARGV[0]);
my $sinefile=$ARGV[1];
system "rm $sinefile";
while(<in>){
	chomp $_;
	my $u=$_;
	system "cat $path/$u/$u.rep.fa >>$sinefile";
}
close in;
