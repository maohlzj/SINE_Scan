#!usr/bin/perl
use strict;

if(@ARGV != 3){
	print "please enter: <origin seeds-blast sequences> <obvious boundaries> <flanksize>\n";
	exit (1);
}

my $flank=$ARGV[2];
open IN,$ARGV[0] or die "$!\n";
my %seq=();###origin seed-blast sequences####
my $u;
while(<IN>){
	chomp $_;
	if($_=~/>/){
		$u=$_;
		$u=~s/>//;
		$seq{$u}="";
	}else{
		$seq{$u}.=uc($_);
	}
}
close IN;

open IN,$ARGV[1] or die "$!\n";
my $five_side=<IN>;
my $three_side=<IN>;
chomp $five_side;
chomp $three_side;
my $Five=0;
my $Three=0;
my $flag=0;

###moving frame two peak are significant and don't overlap 5 and 3####
foreach my $i (keys%seq){
	my $l=length($five_side);
	for(my $j=0;$j<$flank+10;$j++){
		my $frag=substr($seq{$i},$j,$l);
		open out,">moving.fa" or die "$!\n";
		print out">aseq\n$frag\n";
		print out">bseq\n$five_side\n";
		close out;		
		my $peak=similarity("moving.fa");
		if($peak >= 90){
			$Five=$j;		
			$flag++;
		}
	}	
	$l=length($three_side);
	for(my $j=0;$j<$flank+10;$j++){
		my $frag=substr($seq{$i},-$l-$j,$l);
		open out,">moving.fa" or die "$!\n";
		print out">aseq\n$frag\n";
		print out">bseq\n$three_side\n";
		close out;		
		my $peak=similarity("moving.fa");
		if($peak >= 90){
			$Three=length($seq{$i})-$j;		
			$flag++;
		}
	}	
	if($flag == 2){
		my $candidate=substr($seq{$i},$Five,$Three-$Five);
		print "$candidate\n";
	}else{
		print "This candidate doesn't have obvious boundary.\n";
	}
}


sub similarity{
        my $fl=$_[0];
        my $str = Bio::AlignIO->new(-file => $fl);
        my $aln = $str->next_aln();
	my $String=$aln->consensus_string(100);
	my $L=length($String);
	while($String=~/\?/){
		$String=~s/\?//;
	}
	my $r=length($String);
	my $Ratio=int($r*100/$L);
	return $Ratio;
}

